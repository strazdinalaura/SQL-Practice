#UPDATE currency 
#SET conversion_rate_to_usd = 1.25 
#WHERE currency.id = 1;

#UPDATE currency 
#SET conversion_rate_to_usd = 1 
#WHERE currency.id = 2;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.73 
#WHERE currency.id = 3;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.64 
#WHERE currency.id = 4;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.094 
#WHERE currency.id = 5;

#UPDATE currency 
#SET conversion_rate_to_usd = 1.07 
#WHERE currency.id = 6;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.057
#WHERE currency.id = 7;

#USE kickstarter;
#UPDATE currency 
#SET conversion_rate_to_usd = 0.090
#WHERE currency.id = 8;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.59
#WHERE currency.id = 9;

#UPDATE currency 
#SET conversion_rate_to_usd = 1.12
#WHERE currency.id = 10;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.14
#WHERE currency.id = 11;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.13
#WHERE currency.id = 12;

#UPDATE currency 
#SET conversion_rate_to_usd = 0.73
#WHERE currency.id = 13;

UPDATE currency 
SET conversion_rate_to_usd = 0.0068
WHERE currency.id = 14;
